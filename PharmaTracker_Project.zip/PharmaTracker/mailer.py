
import json, smtplib
from datetime import datetime, timedelta

data = json.load(open("harshini.json"))
today = datetime.today().date()
soon = today + timedelta(days=30)

report = ""
for m in data:
    try:
        exp = datetime.strptime(m['expiry_date'], "%Y-%m-%d").date()
        if today <= exp <= soon:
            report += f"{m['name']} | Batch: {m['batch_no']} | Expiry: {m['expiry_date']}\n"
    except: pass

if report:
    body = f"Subject: Expiry Alert\n\n{report}"
    smtp = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    smtp.login("your_email@gmail.com", "your_app_password")
    smtp.sendmail("your_email@gmail.com", "receiver@gmail.com", body)
    smtp.quit()
    print("✅ Email sent.")
else:
    print("✅ No expiry in next 30 days.")
