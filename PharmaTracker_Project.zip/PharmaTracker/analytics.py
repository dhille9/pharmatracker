
import json
from datetime import datetime
from collections import Counter

with open('harshini.json', 'r') as file:
    data = json.load(file)

total = len(data)
low_stock = [m for m in data if int(m['available_stock']) <= 5]
expired = []
today = datetime.today().date()
categories = []

for med in data:
    try:
        exp = datetime.strptime(med['expiry_date'], "%Y-%m-%d").date()
        if exp < today:
            expired.append(med)
    except:
        continue
    categories.append(med['category'])

print(f"🧾 Total medicines: {total}")
print(f"⚠️ Low stock (<=5): {len(low_stock)}")
print(f"⛔ Expired: {len(expired)}")
print("🏷️ Top categories:")
from collections import Counter
for cat, count in Counter(categories).most_common(3):
    print(f" - {cat}: {count}")
