
import json
from datetime import datetime, timedelta

with open('harshini.json', 'r') as file:
    data = json.load(file)

today = datetime.today().date()
next_30 = today + timedelta(days=30)

print("📅 Checking for expiring medicines...\n")
found = False

for med in data:
    try:
        expiry = datetime.strptime(med['expiry_date'], "%Y-%m-%d").date()
        if today <= expiry <= next_30:
            print(f"{med['name']} - Batch {med['batch_no']} - Expiry: {med['expiry_date']}")
            found = True
    except:
        continue

if not found:
    print("✅ No medicines are expiring in the next 30 days.")
