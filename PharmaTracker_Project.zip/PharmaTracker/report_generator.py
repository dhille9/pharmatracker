
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import json

with open("harshini.json", "r") as f:
    data = json.load(f)

c = canvas.Canvas("medicine_report.pdf", pagesize=A4)
width, height = A4
y = height - 40

c.setFont("Helvetica-Bold", 16)
c.drawString(50, y, "PharmaTracker - Medicine Report")
c.setFont("Helvetica", 12)
y -= 40

for med in data:
    text = f"ID: {med['id']} | {med['name']} | Batch: {med['batch_no']} | Stock: {med['available_stock']} | Expiry: {med['expiry_date']}"
    c.drawString(40, y, text)
    y -= 20
    if y < 50:
        c.showPage()
        c.setFont("Helvetica", 12)
        y = height - 40

c.save()
print("✅ PDF Report Generated.")
