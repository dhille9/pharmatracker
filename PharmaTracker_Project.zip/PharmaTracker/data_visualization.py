
import json
import matplotlib.pyplot as plt
from collections import Counter

with open("harshini.json", "r") as f:
    data = json.load(f)

# Bar chart
names = [m['name'] for m in data[:10]]
stocks = [int(m['available_stock']) for m in data[:10]]

plt.figure(figsize=(10, 5))
plt.bar(names, stocks, color='skyblue')
plt.title("Top 10 Medicine Stock")
plt.xlabel("Medicine Name")
plt.ylabel("Stock")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("bar_chart.png")
plt.show()

# Pie chart
categories = [m['category'] for m in data]
counts = Counter(categories)

plt.figure(figsize=(6, 6))
plt.pie(counts.values(), labels=counts.keys(), autopct='%1.1f%%')
plt.title("Category Distribution")
plt.tight_layout()
plt.savefig("pie_chart.png")
plt.show()
