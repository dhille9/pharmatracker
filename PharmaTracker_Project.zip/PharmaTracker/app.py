
from flask import Flask, request, jsonify
import json
from datetime import datetime, timedelta

app = Flask(__name__)
DATA_FILE = 'harshini.json'

def load_data():
    with open(DATA_FILE) as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

@app.route('/')
def home():
    return "Welcome to PharmaTracker API"

@app.route('/medicines', methods=['GET'])
def get_medicines():
    return jsonify(load_data())

@app.route('/add_medicine', methods=['POST'])
def add_medicine():
    new_entry = request.get_json()
    data = load_data()
    new_entry['id'] = max([m['id'] for m in data], default=0) + 1
    data.append(new_entry)
    save_data(data)
    return jsonify({"message": "Medicine added successfully"}), 201

@app.route('/low_stock', methods=['GET'])
def low_stock():
    threshold = int(request.args.get('threshold', 10))
    data = load_data()
    return jsonify([m for m in data if int(m['available_stock']) <= threshold])

@app.route('/expiring_soon', methods=['GET'])
def expiring_soon():
    data = load_data()
    today = datetime.today().date()
    soon = today + timedelta(days=30)
    return jsonify([m for m in data if today <= datetime.strptime(m['expiry_date'], "%Y-%m-%d").date() <= soon])

if __name__ == '__main__':
    app.run(debug=True)
