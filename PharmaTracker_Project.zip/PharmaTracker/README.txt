
PharmaTracker – Medicine Stock and Expiry Tracker

HOW TO RUN:

1. Install dependencies:
   pip install -r requirements.txt

2. Start the Flask API:
   python app.py

3. Run expiry checker:
   python scheduler.py

4. Send email alerts:
   python mailer.py

5. Generate PDF report:
   python report_generator.py

6. Visualize data:
   python data_visualization.py

DATA FILE:
- All medicines are stored in harshini.json (JSON format)
